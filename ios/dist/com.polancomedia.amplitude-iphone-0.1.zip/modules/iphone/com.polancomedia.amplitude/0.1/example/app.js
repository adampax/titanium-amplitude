// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel({
	text: 'Check the console logs'
});
win.add(label);
win.open();

if (Ti.Geolocation.locationServicesEnabled) {
    Titanium.Geolocation.purpose = 'Get Current Location';
    Titanium.Geolocation.getCurrentPosition(function(e) {
        if (e.error) {
            Ti.API.error('Error: ' + e.error);
        } else {
            Ti.API.info(e.coords);
        }
    });
    }

var amplitude = require('com.polancomedia.amplitude');

amplitude.initialize('9ad5ca514ce977f8c6db7cf2f63f5324');

amplitude.setUserId('user123');

amplitude.logEvent('test_event');

amplitude.logEvent('event_with_properties', {myEvent: 'hello'});

